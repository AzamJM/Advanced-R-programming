#' Plot climr output
#'
#' @param x Output from the \code{\link{gp_fit}} function
#' @param ... Other arguments to plot (not currently implemented)
#'
#' @return Nothing: just a nice plot
#' @seealso \code{\link{load_clim}}, \code{\link{gp_fit}}
#' @export
#' @import ggplot2
#' @importFrom stats "sd"
#' @importFrom viridis "scale_color_viridis"
#'
#' @examples
#' data = load_clim("NH")
#' data_fit = gp_fit(data, "BFGS")
#' plot(data_fit)
plot.climr_gp_fit = function(x, ...) {

  # Create global variables to avoid annoying CRAN notes
  DJF = Dec = `J-D` = Jan = SON = Year = month = pred = quarter = temp = year = NULL

  # Create a nice plot from the output of gp_fit.climr

  # scale variables and create predictors
  xx = as.numeric(scale(x$data$year))
  y = as.numeric(scale(x$data$temp))
  x_g = pretty(xx, n = 100)
 
  # Calculate covariance matrix
  C = x$sig_sq * exp( - x$rho_sq * outer(x_g, xx, '-')^2 )
  
  # Create predictions for scaled variables
  pred_gp = C %*% solve(x$Sigma, y)
  
  # Undo the scaling
  df = data.frame(year = x_g * sd(x$data$year) + mean(x$data$year), 
                  pred_temp = pred_gp * sd(x$data$temp) + mean(x$data$temp))
  
  # Finally create the plot
  ggplot(x$data, aes(year, temp)) +
    geom_point(aes(colour = temp)) +
    theme_bw() +
    xlab('Year') +
    ylab('Temperature anomaly') +
    geom_line(data = df, aes(x = df$year, y = df$pred_temp, colour = df$pred_temp)) +
    theme(legend.position = 'None') +
    scale_color_viridis()

}
