#' @importFrom mvtnorm "dmvnorm"
gp_criterion = function(p,x,y) {
  sig_sq = exp(p[1])
  rho_sq = exp(p[2])
  tau_sq = exp(p[3])
  Mu = rep(0, length(x))
  Sigma = sig_sq * exp( - rho_sq * outer(x, x, '-')^2 ) + tau_sq * diag(length(x))
  ll = dmvnorm(y, Mu, Sigma, log = TRUE)
  return(-ll)
}

#' Fit basic statistical models to climate data
#'
#' @param obj An object of class \code{climr} from \code{\link{load_clim}}
#' @param method The method of optimisation required, either \code{Nelder-Mead} or \code{BFGS} or \code{SANN} or \code{Brent}
#'
#' @return Returns a list of class \code{climr_gp_fit} which includes the model details as well as the data set and fit type used
#' @seealso \code{\link{load_clim}}, \code{\link{plot.climr_gp_fit}}
#' @export
#' @importFrom magrittr "%>%"
#' @importFrom stats "optim"
#'
#' @examples
#' ans1 = load_clim('SH')
#' ans2 = gp_fit(ans1, 'BFGS')
gp_fit = function(obj, method = c("Nelder-Mead", "BFGS", "SANN", "Brent")) {
  UseMethod('gp_fit')
}

#' @export
gp_fit.climr = function(obj, method = c("Nelder-Mead", "BFGS", "SANN", "Brent")) {

  # Create global variables to avoid annoying CRAN notes
  DJF = Dec = `J-D` = Jan = SON = Year = month = pred = quarter = temp = x = year = NULL

  # Find what type of fitting method
  method_arg = match.arg(method)

  # Scale variable to fit the model
  x = obj$clim_year$year %>% scale %>% as.numeric
  y = obj$clim_year$temp %>% scale %>% as.numeric
  
  # Find best hyperparameters
  optim_res = optim(rep(0, 3), gp_criterion, x = x, y = y, method = method_arg)
  
  # Extract the results
  sig_sq = optim_res$par[1] %>% exp
  rho_sq = optim_res$par[2] %>% exp
  tau_sq = optim_res$par[3] %>% exp
  
  # Create covariance matrix
  Sigma = sig_sq * exp( - rho_sq * outer(x, x, '-')^2 ) + tau_sq * ( x %>% length %>% diag )
  
  # Output so it can be plotted
  out = list(Sigma = Sigma, sig_sq = sig_sq, rho_sq = rho_sq, tau_sq = tau_sq,
             data = obj$clim_year,
             fit_type = method_arg)
  class(out) = 'climr_gp_fit'

  invisible(out)

}
